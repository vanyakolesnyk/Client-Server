﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Net.Sockets;
using System.Text;
using System.Threading;
using System.Threading.Tasks;

namespace First
{
    class Program
    {
        static void Main(string[] args)
        {
            MyData myData = new MyData();

            myData.UnSerialize();
            Socket s = new Socket(AddressFamily.InterNetwork, SocketType.Dgram, ProtocolType.Udp);

            IPAddress ip = IPAddress.Parse(myData.MulticastGroupIP);

            s.SetSocketOption(SocketOptionLevel.IP, SocketOptionName.AddMembership, new MulticastOption(ip));

            s.SetSocketOption(SocketOptionLevel.IP, SocketOptionName.MulticastTimeToLive, 2);

            IPEndPoint ipep = new IPEndPoint(ip, myData.MulticastGroupHost);

            s.Connect(ipep);
            Random rd = new Random();
            List<byte[]> bss = new List<byte[]>();
            byte[] b = new byte[8];
            int inum = 0;
            while (true)
            {
                
                int a = (int)(rd.Next(myData.LowRandomNum,myData.HaightRandomNum));
                b[0] = (byte)a;
                b[1] = (byte)(a>>8);
                b[2] = (byte)(a>>16);
                b[3] = (byte)(a>>24);
                //b[4] = inum;
                b[4] = (byte)inum;
                b[5] = (byte)(inum >> 8);
                b[6] = (byte)(inum >> 16);
                b[7] = (byte)(inum >> 24);
                bss.Add(b);
                
                s.Send(b, b.Length, SocketFlags.None);
                if (inum == 2147483647)
                    inum = 0;
                else
                    inum++;
            }
        }
    }
}
