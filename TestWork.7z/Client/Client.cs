﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Net.Sockets;
using System.Text;
using System.Threading;
using System.Threading.Tasks;

namespace Client
{
    class Client
    {
        List<int> bs;
        ClientData clientData;
        bool stopthreadbl;
        uint countLose;
        Thread thread, showdate;
        Socket s;
        int bt;
        byte[] b = new byte[8];
        int c;
        void StopThread()
        {
            stopthreadbl = true;
            thread.Abort();
        }
        void StartThread()
        {
            stopthreadbl = false;
            thread = new Thread(TakeAndSaveByte);
            thread.Start();
            while (!thread.IsAlive)
            {
                Thread.Sleep(1);
            }
        }
        public Client()
        {
            clientData = new ClientData();
            clientData.UnSerialize();
            CriateConnection();
            bs = new List<int>();
            stopthreadbl = false;
            countLose = 1;
            thread = new Thread(TakeAndSaveByte);
            thread.Start();
            showdate = new Thread(ShowInfo);
            showdate.Start();
            s.Receive(b);
            c = ((b[3] & 0xFF) << 24) + ((b[2] & 0xFF) << 16) + ((b[1] & 0xFF) << 8) + (b[0] & 0xFF);
            bs.Add(c);
            bt = ((b[7] & 0xFF) << 24) + ((b[6] & 0xFF) << 16) + ((b[5] & 0xFF) << 8) + (b[4] & 0xFF);
        }
        void CriateConnection() {
            s = new Socket(AddressFamily.InterNetwork, SocketType.Dgram, ProtocolType.Udp);

            IPEndPoint ipep = new IPEndPoint(IPAddress.Any, clientData.MulticastGroupHost);
            s.Bind(ipep);

            IPAddress ip = IPAddress.Parse(clientData.MulticastGroupIP);

            s.SetSocketOption(SocketOptionLevel.IP, SocketOptionName.AddMembership, new MulticastOption(ip, IPAddress.Any));

        }
        void TakeAndSaveByte()
        {
            while (!stopthreadbl)
            {
                Thread.Sleep(
                    //clientData.PauseTime
                    1
                    );
                s.Receive(b);
                c = ((b[3] & 0xFF) << 24) + ((b[2] & 0xFF) << 16) + ((b[1] & 0xFF) << 8) + (b[0] & 0xFF);
                
                bs.Add(c);
                if (bt != 2147483647)
                {
                    if(((uint)(((b[7] & 0xFF) << 24) + ((b[6] & 0xFF) << 16) + ((b[5] & 0xFF) << 8) + (b[4] & 0xFF) - bt) - 1)!= 0){
                        countLose += (uint)(((b[7] & 0xFF) << 24) + ((b[6] & 0xFF) << 16) + ((b[5] & 0xFF) << 8) + (b[4] & 0xFF) - bt) - 1;
                    }
                }
                else
                {
                    countLose += (uint)(((b[7] & 0xFF) << 24) + ((b[6] & 0xFF) << 16) + ((b[5] & 0xFF) << 8) + (b[4] & 0xFF));
                }
                bt = ((b[7] & 0xFF) << 24) + ((b[6] & 0xFF) << 16) + ((b[5] & 0xFF) << 8) + (b[4] & 0xFF);

            }
        }
        void ShowInfo()
        {
            
            while (true)
            {
                Console.ReadKey();
                if (bs.Count != 0) 
                {
                    
                    StopThread();
                    double sd = (double)countLose / (double)(countLose + (uint)bs.Count);
                    Console.WriteLine(@"Average: {0} Standart: {1} Moda: {2} Median: {3} lose packages {4}", AvarageDate(bs), StandartDate(bs), Fashion(bs), Median(bs), sd);
                    StartThread();
                }
                else
                    Console.WriteLine("No data received, check if the server application is enabled, and if the IP address and host settings are correct");
            
            }
            
        }
        double AvarageDate(List<int> _bs)
        {
            int sum = 0;
            foreach (int b in _bs)
            {
                sum += b;
            }
            return sum / _bs.Count;
        }
        double StandartDate(List<int> _bs)
        {
            double sum = 0;
            foreach (int b in _bs)
            {
                sum += Math.Pow(b - AvarageDate(_bs), 2);

            }
            return Math.Sqrt(sum / _bs.Count);
        }
        int Fashion(List<int> _bs)
        {
            _bs.Sort();
            int count = 0;
            int _count = 0;
            int ind = 1;
            int last = _bs[0];
            for (int i = 1; i < _bs.Count - 1; i++)
            {
                if (_bs[i] == last)
                {
                    count++;
                }
                else
                {

                    if (count >= _count)
                    {
                        _count = count + 1;
                        ind = i;
                    }
                    count = 0;
                }
                last = _bs[i];

            }
            return _bs[ind - 1];
        }
        int Median(List<int> _bs)
        {
            _bs.Sort();
            if (_bs.Count % 2 == 1)
            {
                return _bs[(_bs.Count + 1) / 2 - 1];
            }
            else
            {
                return (_bs[_bs.Count / 2 - 1] + _bs[_bs.Count / 2]) / 2;
            }
        }

    }
}
